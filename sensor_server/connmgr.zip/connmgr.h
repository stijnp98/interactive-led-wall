#ifndef __CONNMGR_H__
#define __CONNMGR_H__

#include "lib/dplist.h"
#include "lib/tcpsock.h"
#include "config.h"

//function declarations
void connmgr_listen(int port_number);
void connmgr_free();

//structs declaration
typedef struct{
	tcpsock_t* socket;
	sensor_data_t reading;
}node_info;

#endif
