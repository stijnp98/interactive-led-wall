#include <stdio.h>

#include <stdlib.h>

#include <inttypes.h>

#include <assert.h>

#include "config.h"

#include "lib/tcpsock.h"

#include <poll.h>

#include "connmgr.h"

#define MAX_CONN 3 // state the max. number of connections the server will handle before exiting

/* Implements a sequential test server (only one connection at the same time)
 */

void node_free(void ** element);
int node_compare(void * x, void * y);
void * node_copy(void * element);

void connmgr_listen(int port_number) {
  //variable declaration
  tcpsock_t * server, * client;
  sensor_data_t data;
  int bytes, errorval;
  int conn_counter = 0;
  time_t servertime;
  int fd1;             //main connection fd.
  dplist_t* nodes;		// make a list to store all the active connections
  FILE * fp_sensor;

  fp_sensor = fopen("sensor_data_recv","w");
  nodes = dpl_create(node_copy,node_free,node_compare);
  time(&servertime);

  if (tcp_passive_open( & server, port_number) != TCP_NO_ERROR) exit(EXIT_FAILURE);
  printf("Test server is started\n");
  //get the SD of the server in the fd1 variable
  tcp_get_sd(server, & fd1);

  //infinite loop
  while (1) {
  	struct pollfd poll_arg[(1+conn_counter)];
    poll_arg[0].fd = fd1;
    poll_arg[0].events = POLLIN | POLLPRI;
    for(int i = 0;i < conn_counter;i++)
    {
    	node_info* node = (node_info*)dpl_get_element_at_index(nodes,i);
      	poll_arg[(i+1)].fd = node->socket->sd;
    	poll_arg[(i+1)].events = POLLIN | POLLPRI;
    }
    //check if a new connection was made available
    poll(poll_arg, 1 + conn_counter, 500);
    if(poll_arg[0].revents == 1){
    	//if so add the node to the list
    	if (tcp_wait_for_connection(server, & client) != TCP_NO_ERROR) exit(EXIT_FAILURE);
      	printf("Incoming client connection\n");
      	//put the node info in the list.
		node_info* node = (node_info*)malloc(sizeof(node_info));
      	node->socket = client;
      	node->reading.id = 0;
      	node->reading.value = 0;
      	node->reading.ts = 0;
      	dpl_insert_at_index(nodes,(void*)node,conn_counter,false);
      	conn_counter++;
    }
    else if(conn_counter > 0){
     	for(int i =0;i < conn_counter;i++)
      	{
      		//request the information of the node out the list
      		node_info* node = (node_info*)dpl_get_element_at_index(nodes,i);
    		if(poll_arg[(1+i)].revents >= 1)
    		{
    			//change the client information to archive the right info
      			client = node->socket;
      			//clear the errors 
      			errorval = TCP_NO_ERROR;
    			//node send something
        		bytes = sizeof(data.id);
        		errorval = tcp_receive(client, (void * ) &node->reading.id, & bytes,errorval);
        		// read temperature
        		bytes = sizeof(data.value);
        		errorval = tcp_receive(client, (void * ) &node->reading.value, & bytes,errorval);
        		// read timestamp
        		bytes = sizeof(data.ts);
        		errorval = tcp_receive(client, (void * ) &node->reading.ts, & bytes,errorval);
        		switch(errorval)
        		{
        			//everything was OK so process the data that was received.
        			case TCP_NO_ERROR:
        				printf("sensor id = %" PRIu16 " - temperature = %g - timestamp = %ld\n", node->reading.id, node->reading.value, (long int) node->reading.ts);
        				 // write current temperatures to file
      					fwrite(&node->reading.id, sizeof(data.id), 1, fp_sensor);
      					fwrite(&node->reading.value, sizeof(data.value), 1, fp_sensor);
      					fwrite(&node->reading.ts, sizeof(data.ts), 1, fp_sensor);      
        				break;
        			//the connection with the sensor was rejected so that we need to remove this sensor from the list
        			case TCP_CONNECTION_CLOSED:
        				printf("Sensor %d has closed the connection\r\n",node->reading.id);
        				if(tcp_close(&node->socket) == TCP_NO_ERROR)
    					{
        					free(node);
        					dpl_remove_at_index(nodes,i,false);
      						conn_counter--;
      						time(&servertime);
      					}
      					else
    					{
    						printf("a connection was rejected by the client but the server is unable to close the connection\r\n");
    					}
      					break;
      				//a socket error occurs so do nothing with the data.
      				case TCP_SOCKET_ERROR:
      					printf("socket error occured\r\n");
      					break;
      				//invalid command was send over the connection so ignore it for now.
      				case TCP_SOCKOP_ERROR:
      					printf("invalid socket operation was preformed\r\n");

        		}
    		}
    		//check if the client is timedout
    		else if(node->reading.ts < time(NULL) - TIMEOUT)
    		{
    			printf("sensor id = %" PRIu16 " timed out\r\n", node->reading.id);
    			if(tcp_close(&node->socket) == TCP_NO_ERROR)
    			{
    				dpl_remove_at_index(nodes,i,false);
    				free(node);
      				conn_counter--;
    				time(&servertime);
    			}
    			else
    			{
    				printf("something went wrong during a sensor timeout\r\n");
    			}
    		}
      	}
  	}
    else if(servertime < (time(NULL) - TIMEOUT))
    {
    if (tcp_close( & server) != TCP_NO_ERROR) exit(EXIT_FAILURE);
    	printf("No nodes found test server is shutting down\n");
    	dpl_free(&nodes,false);
    	fclose(fp_sensor);
    	printf("exit\r\n");
	}
  }
}

void connmgr_free() 
{
	printf("nothing to free\n");
}

void * node_copy(void * element)
{
    return element;
}   

int node_compare(void * x, void * y)
{
	return -1;
}

void node_free(void ** element)
{
  	free(element);
} 
